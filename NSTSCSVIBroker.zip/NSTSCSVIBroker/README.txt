1. Set the account configuration on netsuite.properties file.
2. To run broker, Java Software version 7 and above is required. Run the broker via
	a. Clicking the jar file
	b. Clicking the Run Via UI.bat to run the broker with user interface
	c. Clicking the Run Via Console.bat to run the broker on console
3. 	For more information, visit confluence page (https://confluence.corp.netsuite.com/display/TTS/CSV+Integrator) or email PS-SuiteSolutions@netsuite.com.
	